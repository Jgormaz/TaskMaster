import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-detalle',
  templateUrl: './detalle.page.html',
  styleUrls: ['./detalle.page.scss'],
})
export class DetallePage implements OnInit {
  // Datos de la actividad en duro
  activity = {
    id: 1,
    description: 'Estudiar para el examen',
    date: '2022-12-25T13:00:00',
    tasks: [
      { title: 'Leer los capítulos de 2 a 5' },
      { title: 'Resolver los ejercicios propuestos' },
      { title: 'Revisar resumen de contenidos' }
    ],
    category: 'Estudios',
    done: false,
    color: '#4caf50' // verdoso
  };

  categories = ['Trabajo', 'Estudios', 'Personal', 'Salud', 'Ocio'];


  pages = [
    { title: 'Inicio', url: '/inicio', icon: 'home' },
    { title: 'Hoy', url: '/hoy', icon: 'calendar' },
    { title: 'Categorías', url: '/categorias', icon: 'folder' },
    { title: 'Añadir tarea', url: '/añadir', icon: 'add' },
    { title: 'Perfil', url: '/perfil', icon: 'person' },
  ];

  constructor() {}

  ngOnInit() {}
  
}

