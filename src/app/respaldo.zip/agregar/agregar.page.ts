import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-agregar',
  templateUrl: './agregar.page.html',
  styleUrls: ['./agregar.page.scss'],
})
export class AgregarPage implements OnInit {


  dateValue: String = new Date().toISOString();
  descripcionTarea = '';

  constructor() { }

  ngOnInit() {
  }

  categorias = [
    { nombre: 'Trabajo', color: '#2196F3' },
    { nombre: 'Estudios', color: '#F44336' },
    { nombre: 'Personal', color: '#4CAF50' },
    // definir todas las categorías y sus colores aquí...
  ];


  colorSeleccionado = '';

  manejarCambioDeCategoria(event: { detail: { value: string; }; }) {
    const categoriaSeleccionada = this.categorias.find(c => c.nombre === event.detail.value);
    if (categoriaSeleccionada) {
      this.colorSeleccionado = categoriaSeleccionada.color;
    }
  }

  tareas: string[] = [''];  
  tareaValores: string[] = [''];

  agregarTarea() {
    this.tareas.push('');
    this.tareaValores.push('');
  }

  obtenerTareasConcatenadas() {
    return this.tareaValores.join(' | ');
  }

  actualizarTarea(index: number, value: string) {
    this.tareaValores[index] = value;
  }

  guardarTareas() {
    this.tareas = [...this.tareaValores];
  }
}




