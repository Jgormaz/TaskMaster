import { Component, OnInit } from '@angular/core';
import { MenuController } from '@ionic/angular';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage implements OnInit {

  pages = [
    { title: 'Inicio', url: '/inicio', icon: 'home' },
    { title: 'Hoy', url: '/hoy', icon: 'calendar' },
    { title: 'Categorías', url: '/categorias', icon: 'folder' },
    { title: 'Añadir tarea', url: '/añadir', icon: 'add' },
    { title: 'Perfil', url: '/perfil', icon: 'person' },
  ];

  progress = [
    { category: 'Trabajo', value: 0.5, color: '#2196F3' }, // Azul
    { category: 'Estudios', value: 0.7, color: '#F44336' }, // Rojo
    { category: 'Personal', value: 0.3, color: '#4CAF50' }, // Verde
    // Agrega más categorías aquí 
  ];

  activities = [
    { time: '8:00', description: 'Desayunar', color: '#4CAF50', done: true },
    { time: '9:00', description: 'Reunión de equipo', color: '#2196F3', done: true },
    { time: '12:00', description: 'Almuerzo', color: '#4CAF50', done: false },
    { time: '18:00', description: 'Prueba App Móviles', color: '#F44336', done: false },
    // Añade más actividades aquí
  ];
  

  constructor(private menuController: MenuController) { }

  ionViewDidEnter() {
    this.menuController.enable(true, 'myMenu');
    this.menuController.open('myMenu');
  }

  calcOffset(value: number) {
    return 440 - (value * 440);
  }


  ngOnInit() {
  }

}
